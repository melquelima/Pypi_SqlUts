# Sql Uts
#
### Installation

```sh
pip install SqlUts
```